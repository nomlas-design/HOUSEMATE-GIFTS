# Planter stand project handoff

## Goal

Design a strong, buildable timber frame for a balcony planter while preserving useful storage space underneath.

## Known geometry

- Planter outside dimensions: approximately **900 mm wide × 400 mm deep × 300 mm high**.
- Desired clear height beneath the supporting frame: approximately **450 mm**.
- Location: residential balcony in Sydney, Australia.
- Intended construction: timber members and ordinary, readily available fasteners.
- The design is exploratory. No final timber species, grade, member sizes, joints or fixing method have been selected.

## Current concept model

The attached `planter-stand-model.html` is an interactive browser model. It currently shows:

- A rectangular top perimeter frame.
- Four corner legs.
- An optional centre cross-member.
- Optional diagonal braces on the long faces.
- A translucent 900 × 400 × 300 mm planter.
- Controls for clearance and nominal timber face width.

Open it in a browser, then drag to orbit and scroll to zoom. It loads Three.js from `esm.sh`, so the browser needs internet access.

`planter-stand-source.html` is the editable model fragment from the original Work conversation. Use it as the source of truth when changing the visualisation.

## Important unresolved inputs

Ask the user for these before treating any arrangement as a recommendation:

1. Maximum loaded planter mass, or enough information to estimate it: planter material/weight, actual soil depth, growing medium and drainage/water-retention arrangement.
2. Timber sizes, species and structural grade readily available locally.
3. Whether the stand may be anchored to a wall, balustrade or balcony slab—and what those elements are made from.
4. Required unobstructed storage opening: front access only, side access, maximum stored-item dimensions, and whether a low rear rail is acceptable.
5. Whether 450 mm means clear space below the lowest beam or total lift to the planter bottom.
6. Exposure to rain, salt air and strong wind, plus whether the balcony has a fall or uneven tiles.

## Structural issues to examine

- Wet mass may be much higher than the dry planter mass. The gross planter volume is about **108 L**, but do not assume it is completely filled with soil.
- Trace vertical load continuously from planter base to joists/rails, legs, feet and balcony surface.
- Check bending and deflection of the 900 mm members, not merely crushing strength.
- Prevent racking in both long and short directions. A heavy planter on four unbraced legs can behave like a parallelogram even when the vertical members are strong.
- Check connection capacity and geometry; screws into end grain should not be treated as the main structural load path.
- Consider planter-bottom support. If the planter is flexible, two long rails alone may be insufficient even if the timber rails themselves are strong.
- Consider overturning/sliding, wind, eccentric loading, water damage, rot separation from wet tiles and adjustable/non-staining feet.
- Consider balcony load capacity and strata/lease restrictions before anchoring anything.

## Suggested next comparison

Create and compare three parametric layouts using the same external dimensions and load assumption:

1. **Open-front frame:** corner legs, front/rear longitudinal bearers, three or more depthwise joists, rear diagonal or sheet bracing; maximises storage access.
2. **Two end trestles:** braced end frames connected by longitudinal bearers; simple load path and potentially good front access.
3. **Cabinet-like braced frame:** perimeter top, legs and a structural rear panel or plywood gussets; strongest racking resistance but less open storage.

For each, show load paths, likely weak points, storage obstruction, approximate cut list and connection concept. Keep engineering calculations transparent and label every assumed material property and load factor. This is preliminary DIY design assistance, not certification of the balcony or structure.

## Continuation prompt

Use this prompt in the Project after uploading the pack:

> Continue this planter-stand design from `START-HERE.md`. Inspect the model and model specification, then ask me only for the unresolved inputs that materially affect the next iteration. After I answer, produce two or three framing layouts with matching dimensions, clear load-path explanations and an updated interactive 3D model. Keep structural assumptions explicit and optimise for useful storage beneath the planter.

